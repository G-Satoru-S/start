package org.efrei.start.controllers;


import org.efrei.start.models.Studio;
import org.efrei.start.services.StudioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/studios")
public class StudioController {

    private final StudioService service;

    @Autowired
    public StudioController(StudioService service) {
        this.service = service;
    }

    @GetMapping
    public List<Studio> getAllStudios() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Studio> getStudioById(@PathVariable String id) {
        Optional<Studio> studio = service.findById(id);
        if (studio.isPresent()) {
            return new ResponseEntity<>(studio.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<Studio> createStudio(@RequestBody Studio studio) {
        Studio newStudio = service.create(studio);
        return new ResponseEntity<>(newStudio, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Studio> updateStudio(@PathVariable String id, @RequestBody Studio studioDetails) {
        Studio updatedStudio = service.update(id, studioDetails);
        return new ResponseEntity<>(updatedStudio, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudio(@PathVariable String id) {
        service.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
