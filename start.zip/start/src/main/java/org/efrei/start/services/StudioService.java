package org.efrei.start.services;


import jakarta.persistence.EntityNotFoundException;
import org.efrei.start.models.Studio;
import org.efrei.start.repositories.StudioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudioService {

    private final StudioRepository repository;

    @Autowired
    public StudioService(StudioRepository repository) {
        this.repository = repository;
    }

    public List<Studio> findAll() {
        return repository.findAll();
    }

    public Optional<Studio> findById(String id) {
        return repository.findById(id);
    }

    public Studio create(Studio studio) {
        return repository.save(studio);
    }

    public Studio update(String id, Studio studioDetails) {
        Studio studio = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Studio not found"));
        studio.setNom(studioDetails.getNom());
        return repository.save(studio);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }
}
