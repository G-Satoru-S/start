package org.efrei.start.dto;

import org.antlr.v4.runtime.misc.NotNull;

public class CreateStudio {

    @NotNull
    private String nom;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}
