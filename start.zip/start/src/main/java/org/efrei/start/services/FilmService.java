package org.efrei.start.services;

import jakarta.persistence.EntityNotFoundException;
import org.efrei.start.models.Film;
import org.efrei.start.repositories.FilmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FilmService {

    private final FilmRepository repository;

    @Autowired
    public  FilmService(FilmRepository repository){
        this.repository= repository;
    }

    public List<Film> FindAll(){
        return repository.findAll();
    }

    public Film findById(String id){
        return repository.findById(id).orElse(null);
    }

    public void create(Film film) {
        repository.save(film);
    }

    public void deleteById(String id) {
        String filmId= id ;  // Déclaration et initialisation de la variable
        Optional<Film> film = repository.findById(filmId);
        if (film.isPresent()) {
            repository.deleteById(filmId);  // Utilisation de filmId ici
        } else {
            throw new EntityNotFoundException("Film not found with id: " + id);
        }
    }


    public void update(String id, Film film) {
        Film existingFilm = findById(id);
        existingFilm.setTitre(film.getTitre());
        existingFilm.setResume(film.getResume());
        repository.save(existingFilm);
    }
}


