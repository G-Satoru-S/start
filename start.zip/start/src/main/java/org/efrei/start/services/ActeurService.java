package org.efrei.start.services;

import org.efrei.start.models.Acteur;
import org.efrei.start.repositories.ActeurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActeurService {

    private final ActeurRepository repository;

    @Autowired
    public ActeurService(ActeurRepository repository) {
        this.repository = repository;
    }

    public List<Acteur> findAll(){
        // SELECT * from actor
        System.out.println(repository.findAll());
        return repository.findAll();
    }

    public void create(Acteur actor) {
        // INSERT INTO actor VALUES(":firstname", ":values")
        repository.save(actor);
    }

    public Acteur findById(String id) {
        // SELECT * FROM actor WERE id = :id
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void update(String id, Acteur actor){
        Acteur updateActor = findById(id);
        updateActor.setNom(actor.getNom());
        updateActor.setPrenom(actor.getPrenom());
        repository.save(updateActor);
    }

}

