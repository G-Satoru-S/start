package org.efrei.start.models;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Film {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "titre", nullable = false, length = 50)
    private String titre;

    @Column(name = "resume", nullable = false, length = 1000)
    private String resume;

    @ManyToMany
    @JoinTable(name = "film_acteur",
            joinColumns = @JoinColumn(name = "film_id"),
            inverseJoinColumns = @JoinColumn(name = "acteur_id"))
    @JsonIgnoreProperties("films")
    private List<Acteur> acteurs;

    @ManyToOne
    @JoinColumn(name = "realisateur_id")  // L'attribut "realisateur" est la clé étrangère
    private Realisateur realisateur;

    @ManyToOne
    @JoinColumn(name = "studio_id")
    private Studio studio;

    public Film(String titre, String resume) {
        this.titre = titre;
        this.resume = resume;
    }

    public Film() {

    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public List<Acteur> getActeurs() { return acteurs;}

    public void setActeurs(List<Acteur> acteurs) { this.acteurs = acteurs;}

    public Realisateur getRealisateur() { return realisateur;}

    public void setRealisateur(Realisateur realisateur) { this.realisateur = realisateur;}

    public Studio getStudio() { return studio;}

    public void setStudio(Studio studio) { this.studio = studio;}

}
