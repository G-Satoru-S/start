package org.efrei.start.dto;

import org.antlr.v4.runtime.misc.NotNull;

public class CreateFilm {
    @NotNull
    private String titre;

    @NotNull
    private String resume;

    private String personnage;

    // Getters and setters
}
