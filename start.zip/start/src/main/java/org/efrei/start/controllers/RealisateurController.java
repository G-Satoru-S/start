package org.efrei.start.controllers;

import org.efrei.start.models.Realisateur;
import org.efrei.start.services.RealisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/realisateurs")

public class RealisateurController {

    private final RealisateurService service;

    @Autowired
    public RealisateurController(RealisateurService service) {
        this.service = service;
    }

    @GetMapping
    public List<Realisateur> getAllRealisateurs() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Realisateur> getRealisateurById(@PathVariable String id) {
        Optional<Realisateur> realisateur = service.findById(id);
        if (realisateur.isPresent()) {
            return new ResponseEntity<>(realisateur.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<Realisateur> createRealisateur(@RequestBody Realisateur realisateur) {
        Realisateur newRealisateur = service.create(realisateur);
        return new ResponseEntity<>(newRealisateur, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Realisateur> updateRealisateur(@PathVariable String id, @RequestBody Realisateur realisateurDetails) {
        Realisateur updatedRealisateur = service.update(id, realisateurDetails);
        return new ResponseEntity<>(updatedRealisateur, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRealisateur(@PathVariable String id) {
        service.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
