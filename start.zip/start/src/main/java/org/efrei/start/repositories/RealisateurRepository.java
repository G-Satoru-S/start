package org.efrei.start.repositories;


import org.efrei.start.models.Realisateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RealisateurRepository extends JpaRepository<Realisateur, String> {
}
