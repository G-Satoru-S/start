package org.efrei.start.dto;

import org.antlr.v4.runtime.misc.NotNull;

public class CreateActeur {
    @NotNull
    private String nom;

    @NotNull
    private String prenom;

    // Getters and setters
}
