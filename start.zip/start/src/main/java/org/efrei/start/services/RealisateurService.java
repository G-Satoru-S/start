package org.efrei.start.services;


import jakarta.persistence.EntityNotFoundException;
import org.efrei.start.models.Realisateur;
import org.efrei.start.repositories.RealisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RealisateurService {

    private final RealisateurRepository repository;

    @Autowired
    public RealisateurService(RealisateurRepository repository) {
        this.repository = repository;
    }

    public List<Realisateur> findAll() {
        return repository.findAll();
    }

    public Optional<Realisateur> findById(String id) {
        return repository.findById(id);
    }

    public Realisateur create(Realisateur realisateur) {
        return repository.save(realisateur);
    }

    public Realisateur update(String id, Realisateur realisateurDetails) {
        Realisateur realisateur = repository.findById(id).orElseThrow(() -> new EntityNotFoundException("Realisateur not found"));
        realisateur.setNom(realisateurDetails.getNom());
        return repository.save(realisateur);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }
}
